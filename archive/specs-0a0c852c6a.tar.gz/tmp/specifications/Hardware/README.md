## Hardware specification v. 0.0.1 

**Profile** 

Thing

**Openschemas specification to describe a hardware component of a computational system** 

# Description 
This Hardware profile specification presents a an abstract representation of hardware used in a computational environment. 
# Links 
- [Specification](https://openschemas.github.io/specifications/Hardware/)
- [Specification source](Hardware.html)
- [Coding Examples](https://github.com/openschemas/specifications/tree/master/Hardware/tree/master/examples)
- [GitHUb Issues](https://github.com/openschemas/specifications/labels/type%3A%20Hardware)
> These files were generated using [map2model](https://github.com/openschemas/map2model) Python Module.